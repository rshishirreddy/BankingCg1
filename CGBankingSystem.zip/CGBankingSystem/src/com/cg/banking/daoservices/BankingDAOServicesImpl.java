package com.cg.banking.daoservices;

import java.util.Random;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public class BankingDAOServicesImpl implements BankingDAOServices {
	private static int CUSTOMER_ID_COUNTER=112 ;
	private static int CUSTOMER_IDX_COUNTER;
	private static long ACCOUNT_NUM_GENERATOR=100000000;
	private static Random random=new Random();
	private Customer[] customerList=new Customer[10];
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
				if(getCustomer(customerId)!=null){
				account.setAccountNo(ACCOUNT_NUM_GENERATOR++);
				getCustomer(customerId).getAccounts()[getCustomer(customerId).getAccountCounter()]=account;
				getCustomer(customerId).getAccounts()[getCustomer(customerId).getAccountCounter()].setStatus("ACTIVE");
				getCustomer(customerId).setAccountCounter(getCustomer(customerId).getAccountCounter()+1);				
				return 	getCustomer(customerId).getAccounts()[getCustomer(customerId).getAccountCounter()-1].getAccountNo();	
				}
				return 0;
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==account.getAccountNo()){
				getCustomer(customerId).getAccounts()[i]=account;	
				return true;
			}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {		
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==account.getAccountNo()){
				getCustomer(customerId).getAccounts()[i].setPinNumber(random.nextInt(10000));
				return getCustomer(customerId).getAccounts()[i].getPinNumber();
			}
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)!=null){
			transaction.setTransactionId(random.nextInt(100000000));
			getAccount(customerId, accountNo).getTransactions()[	getAccount(customerId, accountNo).getTransactionCounter()]=transaction;
			getAccount(customerId, accountNo).setTransactionCounter(getAccount(customerId, accountNo).getTransactionCounter()+1);
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				customerList[i]=null;
				for(int j=i;j<customerList.length&&(j+1)!=customerList.length;j++){
					customerList[j]=customerList[j+1];
					customerList[j+1]=null;
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<getAccounts(customerId).length;i++){
			if(getAccounts(customerId)[i].getAccountNo()==accountNo){
				getAccounts(customerId)[i]=null;
				for(int j=i;j<getAccounts(customerId).length&&(j+1)!=getAccounts(customerId).length;j++){
					getAccounts(customerId)[j]=getAccounts(customerId)[j+1];
					getAccounts(customerId)[j+1]=null;
				}
				return true;
			}
		}
		return false;
	}
	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId)
				return customerList[i];
		return null;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo)
				return getCustomer(customerId).getAccounts()[i];
		return null;
	}
	@Override
	public Customer[] getCustomers() {

		return customerList;
	}
	@Override
	public Account[] getAccounts(int customerId) {

		return getCustomer(customerId).getAccounts();
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {

		return getAccount(customerId, accountNo).getTransactions();
	}
}
